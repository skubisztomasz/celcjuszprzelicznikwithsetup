using System.Windows.Forms;
using System;

namespace Celcjusz_przelicznik
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Wprowad� liczb� stopni Celsiusza.", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (double.TryParse(textBox1.Text, out double celsius))
            {
                double fahrenheit = (celsius * 9 / 5) + 32;
                double kelvin = celsius + 273.15;

                textBox2.Text = fahrenheit.ToString("0.00");
                textBox3.Text = kelvin.ToString("0.00");
            }
            else
            {
                MessageBox.Show("Wprowadzona warto�� nie jest liczb�.", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}